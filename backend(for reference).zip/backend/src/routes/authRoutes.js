import express from 'express';
// 👇 MAKE SURE getMe IS IN THIS LIST RIGHT HERE 👇
import { login, register, getMe } from '../controllers/authController.js'; 
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/login', login);
router.post('/register', register);
router.get('/me', protect, getMe);

export default router;